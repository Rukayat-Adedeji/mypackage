# -*- coding: utf-8 -*-
from mypackage import myModule

